package client

import ru.vtb.jira.rest.core.misc.JsonConstants

/**
 * The IssueWorks provides all custom methods for Jira Issues at VTB
 */
interface IssueWorks {
    /**
     * метод получаем список проектов, возвращаем в форме Json TODO сделать/найти парсер
     *
     */
    fun getAllProjects() {}

    /**
     * метод создает и возвращает номер вновь созданной задачи типа String
     * creatorOfIssue - username создателя
     * issueTitle - заголовок (тема)
     * textDiscription - описание бага/задачи
     * -------------------------------------------------------------------------------------------------
     * FieldsBean - основной объект для API взаимодействия
     * UserBean - объект для работы с даннами пользователя (emailAddress, name, avatar etc.)
     * Обозначения в задаче:
     * setDescription - Шапка описания
     * setSummary - Название задачи
     * setKey - название проекта, если что можно вытянуть методом getAllProjects(). Пример: "key":"EFR"
     * issueType.setName - тип задачи (Bug, Story и т.п.)
     * priority.setName - приоритет задачи (Low, Medium, High) лежит в interface JsonConstants
     * setLabels - метки к задаче
     */
    fun createIssue(issueAuthor: String, issueTitle: String, textDiscription: String): String? {
        return null
    }

    /** Метод по JQL запросу, возвращает Project Key в виде: JAT-*** TODO сделать/найти парсер
     * @param query = 1) String запрос
     *                2) Cоздание кастомного JQL запроса на основе "конструктора" вида:
    val builder = JqlBuilder()
    val jql = builder.addCondition(EField.PROJECT, EOperator.EQUALS, "Jira_Api_test")
    .and().addCondition(EField.STATUS, EOperator.EQUALS, JqlConstants.STATUS_TODO)
    .orderBy(SortOrder.ASC, EField.CREATED)
    + прочее из enum EField, например:
    + поле jsb.addField(EField.ISSUE_KEY, EField.STATUS, EField.DUE, EField.SUMMARY, EField.ISSUE_TYPE, EField.PRIORITY, EField.UPDATED, EField.TRANSITIONS)
     */
    fun searchIssue(query: String) {}

    /**
     * Добавление/ Удаление меток (входной параметр дефект из п2)
     * operations - используется для указания действия: SET,REMOVE,ADD.
     * update[JsonConstants.PROP_LABELS] = operations - тут мы присваиваем nod в JSON для редактирования из JIRA Environment в видe :"labels":["AT","EFR","bug"]
     * @param addLabel = true = добавить, false - удалить
     * @param issueKey  = key of current issue
     */
    fun changeIssueLabel(labelName: String, issueKey: String, addLabel: Boolean) {}

    /**
     * Добавление комментария
     */
    fun addCommentToIssue(issueKey: String, comment: String) {}

    /**
     * Изменения среды Environment (под labels)
     */
    fun changeIssueEnvironment(issueKey: String) {}

    /**
     * Вложение файла в задачу(под labels)
     */
    fun saveAttachment(issueKey: String) {}

}
