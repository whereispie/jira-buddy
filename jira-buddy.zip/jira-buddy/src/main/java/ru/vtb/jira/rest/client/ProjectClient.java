package ru.vtb.jira.rest.client;

import ru.vtb.jira.rest.core.domain.ComponentBean;
import ru.vtb.jira.rest.core.domain.ProjectBean;
import ru.vtb.jira.rest.core.domain.VersionBean;
import ru.vtb.jira.rest.core.domain.meta.MetaBean;
import ru.vtb.jira.rest.core.util.RestException;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.Future;

/**
 * The IssueClient provides all Informations for Jira Issues
 * <p/>
 * User: SEE esavkin@vtb.ru
 */
public interface ProjectClient {


    /**
     * Returns a list of all projects the logged in User can see..
     *
     * @return list of projects
     * @throws RestException
     */
    Future<List<ProjectBean>> getAllProjects();

    /**
     * Returns a full representation of the project for the given key.
     *
     * @param projectKey = the project key
     * @return all informations for the project
     * @throws RestException
     */
    Future<ProjectBean> getProjectByKey(final String projectKey);

    /**
     * Returns a list of all versions for a project.
     *
     * @param projectKey = the project key
     * @return list of versions
     * @throws RestException
     */
    Future<List<VersionBean>> getProjectVersions(final String projectKey);


    /**
     * Returns a list of all components for a project.
     *
     * @param projectKey = the project key
     * @return list of components
     * @throws RestException
     */
    Future<List<ComponentBean>> getProjectComponents(final String projectKey);


    /**
     * Return the Meta Data for the IssueTypes of a Project. This includes all possible IssueTypes and the Fields including the AllowedValues
     *
     * @param projectKey
     * @return
     */
    Future<MetaBean> getIssueTypesMetaForProject(final String projectKey);

}
